

export default function BoutonAjout(props){
    
    
    return <div className="boutonAjou">+</div>
}