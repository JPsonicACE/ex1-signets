import React from 'react';
import ReactDOM from 'react-dom';
import './index.scss';
import Appli from './Appli';

ReactDOM.render(
  <React.StrictMode>
    <Appli />
  </React.StrictMode>,
  document.getElementById('racine')
);
