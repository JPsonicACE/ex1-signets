import './Entete.scss';
function Entete(props){


    return(

        <header className="Entete">
            <div className="nameSignet">Signet</div>
            <div className="nameAutor">Camille Seeman</div>
            <div className="Icon">Icone</div>
          
        </header>
    )
}

export default Entete;